enum EstadoReserva {
    Abierta,
    Cerrada,
    Cancelada
};
