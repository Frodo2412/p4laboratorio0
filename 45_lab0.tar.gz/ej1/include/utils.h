//
// Created by unzip on 19/3/22.
//

#ifndef P4LABORATORIO0_UTILS_H
#define P4LABORATORIO0_UTILS_H

const int MAX_HUESPEDES = 100;
const int MAX_HABITACIONES = 100;
const int MAX_RESERVAS = 100;


#endif //P4LABORATORIO0_UTILS_H
